module Main (main) where

import P1A_EX1.P1A_EX1
import P1A_EX2.P1A_EX2
import P1A_EX3.P1A_EX3
import P2B_EX1.P2B_EX1
import P2B_EX2.P2B_EX2


main :: IO ()
main = do
       main1
       main2
       main3
       main4
       main5
       
       
       
